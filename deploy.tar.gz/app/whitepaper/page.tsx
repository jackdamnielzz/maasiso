import WhitepaperClientWrapper from '@/components/features/WhitepaperClientWrapper';

export default function WhitepaperPage() {
  return <WhitepaperClientWrapper />;
}