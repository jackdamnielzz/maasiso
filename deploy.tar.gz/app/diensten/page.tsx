import { Metadata } from 'next';
import { getPage } from '@/lib/api';
import { Page } from '@/lib/types';
import { Feature } from '@/lib/types';

import { getIconForFeature } from '@/lib/utils/iconMapper';

export const metadata: Metadata = {
  title: 'Diensten | MaasISO - ISO-certificering & Informatiebeveiliging',
  description: 'Ontdek de diensten van MaasISO op het gebied van ISO-certificering, informatiebeveiliging, AVG-compliance en meer. Professionele begeleiding voor uw organisatie.',
  keywords: 'ISO 9001, ISO 27001, ISO 27002, ISO 14001, ISO 16175, informatiebeveiliging, AVG, GDPR, privacy consultancy, BIO'
};

// Force dynamic rendering to ensure fresh content from Strapi
export const dynamic = 'force-dynamic';
export const revalidate = 0;


export default async function DienstenPage() {
  // Fetch content from Strapi
  let pageData = null;
  let hasValidContent = false;

  try {
    console.log("[Diensten] Fetching page data directly from Strapi...");
    pageData = await getPage('diensten');

    console.log("[Diensten] Page data retrieved:", {
      success: !!pageData,
      hasLayout: !!pageData?.layout,
      layoutCount: pageData?.layout?.length || 0,
      componentTypes: pageData?.layout?.map((item: any) => item.__component)
    });

    // Check if we have valid content to render
    hasValidContent = Boolean(pageData && pageData.layout && pageData.layout.length > 0);

    // Log feature grid components if any
    if (pageData?.layout) {
      const featureGridComponents = pageData.layout.filter(block => block.__component === 'page-blocks.feature-grid');
      console.log(`[Diensten] Found ${featureGridComponents.length} feature-grid components`);

      // Log features count for each feature grid
      featureGridComponents.forEach((grid, index) => {
        console.log(`[Diensten] Feature grid #${index + 1} has ${grid.features?.length || 0} features`);
      });
    }
  } catch (error) {
    console.error('Error fetching Strapi content:', error);
    console.log('[Diensten] Attempting to fetch from simple-diensten-test API endpoint...');

    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'}/api/simple-diensten-test`);
      const data = await response.json();
      console.log('[Diensten] simple-diensten-test response:', data);
    } catch (fallbackError) {
      console.error('[Diensten] Fallback API call also failed:', fallbackError);
    }

    // Enhanced error logging
    if (error instanceof Error) {
      console.error(`[Diensten] Error details: ${error.message}`);
      if ('status' in error) {
        const status = (error as any).status;
        console.error(`[Diensten] Error status: ${status}`);
      }
    }
    hasValidContent = false;
  }

  // If we don't have valid content from Strapi, use fallback content
  if (!hasValidContent) {

    return (
      <main className="flex-1 bg-gradient-to-b from-blue-50 to-white" data-testid="diensten-fallback-content">
        <section className="py-16 md:py-24">
          <div className="container-custom px-4 sm:px-6 lg:px-8">
            <div className="bg-white rounded-lg shadow-md overflow-hidden mb-10 max-w-3xl mx-auto relative">
              <div className="h-1.5 bg-gradient-to-r from-[#00875A] via-[#00875A] to-[#FF8B00]"></div>

              <div className="p-8 md:p-10 text-center">
              <h2 className="text-2xl md:text-3xl font-bold mb-6 text-[#091E42]">
                  MaasISO Diensten
                </h2>
                <p className="text-gray-600 mb-4">
                  De inhoud van deze pagina wordt geladen vanuit het Content Management Systeem (Strapi).
                </p>
                <p className="text-gray-600">
                  Neem contact op met de beheerder als deze melding blijft bestaan.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
    );
  }

  // Display dynamic content if available
  if (hasValidContent) {
    return (
      <main className="flex-1 bg-gradient-to-b from-blue-50 to-white" data-testid="diensten-dynamic-content">
        {pageData?.layout?.map((block: any) => {
          switch (block.__component) {
            case 'page-blocks.hero':
              return (
                <section key={block.id} className="hero-section relative overflow-hidden">
                  {/* Decorative elements */}
                  <div className="absolute top-0 left-0 w-full h-full overflow-hidden">
                    <div className="absolute top-0 right-0 w-96 h-96 bg-[#00875A] rounded-full opacity-10 -mr-20 -mt-20 animate-pulse-slow"></div>
                    <div className="absolute bottom-0 left-0 w-72 h-72 bg-[#FF8B00] rounded-full opacity-10 -ml-20 -mb-20 animate-pulse-slow delay-300"></div>
                    <div className="absolute top-1/2 left-1/4 w-40 h-40 bg-white rounded-full opacity-5 transform -translate-y-1/2"></div>
                  </div>

                  <div className="container-custom relative z-10">
                    <div className="text-center">
                      <h1 className="text-4xl md:text-5xl font-bold mb-6 text-white">
                        {block.title}
                      </h1>
                      {block.subtitle && (
                        <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl mx-auto">
                          {block.subtitle}
                        </p>
                      )}
                      {block.ctaButton && (
                        <a
                          href={block.ctaButton.link}
                          className="primary-button hover:bg-[#FF9B20] hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
                        >
                          {block.ctaButton.text}
                        </a>
                      )}
                    </div>
                  </div>
                </section>
              );

            case 'page-blocks.text-block':
              return (
                <section key={block.id} className="py-16 md:py-24">
                  <div className="container-custom px-4 sm:px-6 lg:px-8">
                    <div className="bg-white rounded-lg shadow-md overflow-hidden mb-10 max-w-4xl mx-auto relative hover:shadow-xl transition-all duration-300">
                      <div className="h-1.5 bg-gradient-to-r from-[#00875A] via-[#00875A] to-[#FF8B00]"></div>
                      <div className="p-8 md:p-10">
                        <div className="absolute top-12 right-12 opacity-10">
                          <svg className="w-32 h-32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="#091E42" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                            <path d="M2 17L12 22L22 17" stroke="#091E42" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                            <path d="M2 12L12 17L22 12" stroke="#091E42" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                          </svg>
                        </div>
                        <div
                          className={`space-y-8 relative z-10 prose prose-headings:text-[#091E42] prose-a:text-[#00875A] prose-strong:text-[#091E42] prose-strong:font-semibold prose-em:text-gray-700 prose-p:leading-relaxed prose-p:text-base prose-p:my-6 max-w-none text-${block.alignment || 'left'}`}
                          dangerouslySetInnerHTML={{ __html: block.content }}
                        />
                      </div>
                    </div>
                  </div>
                </section>
              );

            case 'page-blocks.feature-grid':
              return (
                <section key={block.id} className="py-16 md:py-24 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-72 h-72 bg-[#00875A] rounded-full opacity-5 -mr-20 -mt-20"></div>
                  <div className="absolute bottom-0 left-0 w-72 h-72 bg-[#FF8B00] rounded-full opacity-5 -ml-20 -mb-20"></div>

                  <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    {block.features && block.features.length > 0 ? (
                      <>
                        <div className="text-center mb-16">
                          <h2 className="text-3xl md:text-4xl font-bold text-center mb-6 relative inline-block">
                            {block.title || 'Onze Diensten'}
                            <span className="absolute -bottom-3 left-1/2 w-20 h-1 bg-[#00875A] transform -translate-x-1/2"></span>
                          </h2>
                          {block.subtitle && (
                            <p className="text-gray-600 text-center max-w-2xl mx-auto mt-6">
                              {block.subtitle}
                            </p>
                          )}
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8 xl:gap-10 w-full max-w-[95%] sm:max-w-[85%] md:max-w-5xl mx-auto mb-8" data-testid="service-cards-grid">
                          {block.features.map((feature: any, index: number) => (
                            <div
                              key={feature.id}
                              className="service-card bg-white p-5 sm:p-6 md:p-7 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 group relative hover:-translate-y-2 flex flex-col h-full border border-gray-100 overflow-hidden max-w-sm mx-auto w-full"
                              data-testid={`service-card-${feature.id}`}
                            >
                              {/* Top accent bar */}
                              <div className="absolute top-0 left-0 right-0 h-3 bg-gradient-to-r from-[#00875A] to-[#FF8B00]"></div>

                              <div className="flex items-center justify-center mb-6 sm:mb-8">
                                {feature.icon && feature.icon.url ? (
                                  <div className="flex-shrink-0 w-16 sm:w-20 h-16 sm:h-20 bg-blue-50 rounded-full flex items-center justify-center group-hover:bg-blue-100 transition-all duration-300 border border-blue-100 group-hover:border-blue-200 shadow-sm">
                                    <img

                                      src={feature.icon.url}

                                      alt={feature.icon.alternativeText || feature.title || 'Service icon'}

                                      className="h-8 sm:h-10 w-8 sm:w-10"

                                      data-testid="service-icon"

                                    />

                                  </div>
                                ) : (
                                  <div className="flex-shrink-0 w-16 sm:w-20 h-16 sm:h-20 bg-blue-50 rounded-full flex items-center justify-center group-hover:bg-blue-100 transition-all duration-300 border border-blue-100 group-hover:border-blue-200 shadow-sm">
                                    <img
                                      src={getIconForFeature(feature.title || '')}
                                      alt={feature.title || 'Service icon'}
                                      className="h-8 sm:h-10 w-8 sm:w-10"
                                      data-testid="service-icon"
                                    />
                                  </div>
                                )}
                              </div>

                              <div className="text-center mb-6 min-w-0">
                                <h3 className="text-lg sm:text-xl font-semibold text-gray-900 group-hover:text-[#00875A] transition-colors duration-300 break-words">
                                  {feature.title || 'Service Title'}

                                </h3>
                              </div>

                              {feature.description && feature.description.trim() !== '' ? (
                                <div className="bg-gray-50 p-4 sm:p-5 rounded-lg flex-grow mb-6 border border-gray-100 hover:border-[#00875A] transition-colors duration-300 shadow-sm">
                                  <p className="text-left text-gray-700 leading-relaxed group-hover:text-gray-800 transition-colors duration-300 break-words">
                                    {feature.description}
                                  </p>
                                </div>
                              ) : (
                                <div className="bg-gray-50 p-4 sm:p-5 rounded-lg flex-grow mb-6 border border-gray-100 hover:border-[#00875A] transition-colors duration-300 shadow-sm">
                                  <p className="text-left text-gray-700 leading-relaxed group-hover:text-gray-800 transition-colors duration-300 break-words">
                                    Wij bieden professionele begeleiding en advies voor {feature.title}.
                                  </p>
                                </div>
                              )}

                              {feature.link ? (
                                <div className="mt-auto pt-4 border-t border-gray-100 text-center">
                                  <a href={feature.link} className="text-sm text-[#00875A] font-medium transition-all duration-300 inline-flex items-center justify-center">
                                    Meer informatie <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                    </svg>
                                  </a>
                                </div>
                              ) : (
                                <div className="mt-auto pt-4 border-t border-gray-100 text-center">
                                  <span className="text-sm text-[#00875A] font-medium transition-all duration-300 inline-flex items-center justify-center">
                                    Meer informatie <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                    </svg>
                                  </span>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </>
                    ) : (
                      <div className="py-8">
                        <div className="w-20 h-1 bg-[#00875A] mx-auto"></div>
                      </div>
                    )}
                  </div>
                </section>
              );

            case 'page-blocks.button':
              return (
                <section key={block.id} className="bg-[#091E42] text-white py-16 md:py-24 relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-full overflow-hidden">
                    <div className="absolute top-0 right-0 w-96 h-96 bg-[#00875A] rounded-full opacity-10 -mr-20 -mt-20 animate-pulse-slow"></div>
                    <div className="absolute bottom-0 left-0 w-72 h-72 bg-[#FF8B00] rounded-full opacity-10 -ml-20 -mb-20 animate-pulse-slow delay-300"></div>
                    <div className="absolute top-1/2 left-1/4 w-40 h-40 bg-white rounded-full opacity-5 transform -translate-y-1/2"></div>
                  </div>
                  <div className="container-custom text-center relative z-10 px-4 sm:px-6 lg:px-8">
                    <h2 className="text-3xl md:text-4xl font-bold mb-8 leading-tight">
                      {block.title || "Klaar om uw organisatie naar een hoger niveau te tillen?"}
                    </h2>
                    <p className="text-xl text-white/90 mb-10 max-w-3xl mx-auto leading-relaxed">
                      {block.description || "Neem contact op voor een vrijblijvend gesprek over hoe MaasISO u kan helpen met ISO-certificering en informatiebeveiliging."}
                    </p>
                    <a
                      href={block.link}
                      className="primary-button hover:bg-[#FF9B20] hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
                    >
                      {block.text}
                    </a>
                  </div>
                </section>
              );

            default:
              return null;
          }
        })}
      </main>
    );
  }
}