import type { Metadata } from 'next';
import { getNewsArticleBySlug, getNewsArticles } from '@/lib/api';
import NewsArticleWrapper from '@/components/features/NewsArticleWrapper';
import { notFound } from 'next/navigation';
import { NewsArticle } from '@/lib/types';
import { getExcerpt } from '@/lib/utils';


export 
const dynamic = 'force-dynamic';

export async function generateMetadata(props: any): Promise<Metadata> {
  try {
    const { slug } = props.params;
    
    if (!slug) {
      return {
        title: 'News Article Not Found',
        description: 'The requested news article could not be found.'
      };
    }

    const article = await getNewsArticleBySlug(slug);
    if (!article) {
      return {
        title: 'News Article Not Found',
        description: 'The requested news article could not be found.'
      };
    }

    const description = article.summary || getExcerpt(article.content || '', 155);
    const mainCategory = article.categories?.[0]?.name;
    const imageUrl = article.featuredImage?.url;

    return {
      title: `${article.seoTitle || article.title} | MaasISO`,
      description: article.seoDescription || description,
      openGraph: {
        title: article.seoTitle || article.title,
        description: article.seoDescription || description,
        type: 'article',
        publishedTime: article.publishedAt,
        modifiedTime: article.updatedAt,
        authors: article.author ? [article.author] : undefined,
        images: imageUrl ? [{ url: imageUrl }] : undefined,
        ...(mainCategory && { tags: [mainCategory] })
      }
    } as Metadata;
  } catch (error) {
    // On error, return default metadata
    if (error instanceof Error) {
      console.error('Error generating metadata:', error.message);
    }
    return {
      title: 'Error Loading News Article',
      description: 'There was an error loading the news article.'
    };
  }
}

export default async function NewsArticlePage(props: any) {
  try {
    const { slug } = props.params;
    
    if (!slug) {
      notFound();
    }

    const article = await getNewsArticleBySlug(slug);
    
    if (!article || !article.content) {
      notFound();
    }

    return <NewsArticleWrapper article={article} />;
  } catch (error) {
    // Let the error boundary handle the error display
    if (error instanceof Error) {
      throw new Error(`Er is een fout opgetreden bij het laden van het nieuwsartikel: ${error.message}`);
    }
    throw new Error('Er is een onverwachte fout opgetreden bij het laden van het nieuwsartikel.');
  }
}
