import HomeContentWrapper from '@/components/home/HomeContentWrapper';

export default function Home() {
  return <HomeContentWrapper />;
}
