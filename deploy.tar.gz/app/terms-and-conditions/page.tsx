import fs from 'fs/promises';
import path from 'path';
import React from 'react';
import MarkdownContent from '@/components/features/MarkdownContent';
import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Algemene Voorwaarden | MaasISO',
  description: 'Onze algemene voorwaarden en bepalingen voor dienstverlening',
};

async function getTermsContent() {
  const filePath = path.join(process.cwd(), 'algemenevoorwaarden.md');
  const content = await fs.readFile(filePath, 'utf8');
  return content;
}

export default async function TermsAndConditionsPage() {
  const termsContent = await getTermsContent();

  return (
    <div className="min-h-screen bg-gray-50">
      <section className="hero-section">
        <div className="container-custom text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Algemene <span className="text-[#FF8B00]">Voorwaarden</span>
          </h1>
          <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto">
            Onze voorwaarden en bepalingen voor professionele dienstverlening
          </p>
        </div>
      </section>

      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <MarkdownContent content={termsContent} />
        </div>
      </div>
    </div>
  );
}