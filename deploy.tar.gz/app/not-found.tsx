import NotFoundContentWrapper from '../src/components/error/NotFoundContentWrapper';

export default function NotFound() {
  return <NotFoundContentWrapper />;
}
