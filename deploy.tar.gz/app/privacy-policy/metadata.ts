export const metadata = {
  title: 'Privacy & Cookie Beleid | MaasISO',
  description: 'Ons privacy- en cookiebeleid: hoe wij omgaan met uw gegevens en cookies op onze website.',
};