# Enhanced deployment script with version checks and BOM handling
param(
    [Parameter(Mandatory=$false)]
    [switch]$SkipBuild,
    [Parameter(Mandatory=$false)]
    [int]$HealthCheckRetries = 5,
    [Parameter(Mandatory=$false)]
    [int]$HealthCheckDelay = 10,
    [Parameter(Mandatory=$false)]
    [string]$BackupDir = "/var/www/backups",
    [Parameter(Mandatory=$false)]
    [int]$BuildTimeout = 300,
    [Parameter(Mandatory=$false)]
    [switch]$SkipBackup
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$VPS = "147.93.62.188"
$RemotePath = "/var/www/jouw-frontend-website"
$SshKeyPath = "$env:USERPROFILE\.ssh\maasiso_vps"

# Create temp directory for build
$tempDir = Join-Path $env:TEMP "maasiso-build-$(Get-Date -Format 'yyyyMMddHHmmss')"
New-Item -ItemType Directory -Path $tempDir | Out-Null

function Write-Step {
    param([string]$Message)
    Write-Host "`n🚀 $Message" -ForegroundColor Cyan
    Write-Host "================================================"
}

function Write-SubStep {
    param(
        [string]$Message,
        [string]$Status = "Running"
    )
    $color = switch($Status) {
        "Running" { "Yellow" }
        "Success" { "Green" }
        "Error" { "Red" }
        "Warning" { "DarkYellow" }
        default { "White" }
    }
    Write-Host "  → $Message" -ForegroundColor $color
}

function Get-UserConfirmation {
    param([string]$Message)
    $response = Read-Host "$Message (y/n)"
    return $response.ToLower() -eq 'y'
}

function Create-Backup {
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $backupName = "frontend_backup_${timestamp}.tar.gz"
    $backupCommand = "mkdir -p $BackupDir && cd $RemotePath && tar -czf $BackupDir/$backupName ."
    return $backupCommand, $backupName
}

function Stop-NodeProcesses {
    Get-Process -Name "node", "npm" -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            $_.Kill()
            $_.WaitForExit()
        } catch {
            Write-SubStep "Failed to kill process $($_.Id): $_" -Status "Warning"
        }
    }
}

try {
    $startTime = Get-Date
    
    # 0. Check Node.js version on server
    Write-Step "Checking Server Environment"
    $nodeVersion = ssh -i $SshKeyPath "root@$VPS" "node -v"
    if ($nodeVersion -notmatch "v20") {
        Write-SubStep "Updating Node.js on server..." -Status "Warning"
        $updateNodeCommand = @'
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs
npm install -g npm@latest
'@
        ssh -i $SshKeyPath "root@$VPS" $updateNodeCommand
        Write-SubStep "Node.js updated on server" -Status "Success"
    }
    
    # 1. Copy project files to temp directory
    Write-Step "Preparing Build Environment"
    Write-SubStep "Copying project files to temporary directory..."
    
    # Stop any running Node processes
    Stop-NodeProcesses
    
    # Copy all files except node_modules and .next
    Get-ChildItem -Path . -Exclude @("node_modules", ".next", ".git") | Copy-Item -Destination $tempDir -Recurse
    
    # Set up environment file
    $envContent = @"
NEXT_PUBLIC_API_URL=http://153.92.223.23:1337
NEXT_PUBLIC_BACKEND_URL=http://153.92.223.23:1337
NEXT_PUBLIC_SITE_URL=https://maasiso.nl
NEXT_PUBLIC_STRAPI_TOKEN=6615dd3e4c34a3dbee678b75077450028605e4110a2ac4414294618f91770cd2c1121f5539af11487a0cb4142a34f5d0db81b49c7aabd14481c5cf029aa4c257a89326bb00492f2130cdd07fae6141f1e266e9a7773e9f215ab4e133719bf7455b2d24ea16a2e3bbceb396e1b4c1fb95e1d4755f67666902fe3b1d734c236f86
"@
    Set-Content -Path (Join-Path $tempDir ".env.production") -Value $envContent -NoNewline -Encoding UTF8
    Write-SubStep "Environment configured" -Status "Success"
    
    # 2. Build in temp directory
    if(-not $SkipBuild) {
        Write-Step "Building Application"
        Push-Location $tempDir
        
        try {
            Write-SubStep "Installing dependencies..."
            npm install --no-audit --no-fund --legacy-peer-deps
            if ($LASTEXITCODE -ne 0) { throw "npm install failed" }
            
            Write-SubStep "Building application..."
            npm run build:prod
            if ($LASTEXITCODE -ne 0) { throw "Build failed" }
            
            Write-SubStep "Build completed successfully" -Status "Success"
        }
        finally {
            Pop-Location
        }
    }
    
    # 3. Handle backup
    $createBackup = -not $SkipBackup
    if ($createBackup) {
        Write-Step "Backup Configuration"
        $createBackup = Get-UserConfirmation "Do you want to create a backup before deploying?"
    }

    $backupName = $null
    if ($createBackup) {
        Write-Step "Creating Backup"
        $backupCommand, $backupName = Create-Backup
        $backupCommand = $backupCommand -replace "`r`n", "`n"
        
        ssh -i $SshKeyPath "root@$VPS" $backupCommand
        Write-SubStep "Backup created: $backupName" -Status "Success"
    } else {
        Write-SubStep "Skipping backup creation" -Status "Warning"
    }
    
    # 4. Create deployment package
    Write-Step "Creating Deployment Package"
    Push-Location $tempDir
    try {
        tar -czf deploy.tar.gz --exclude=".git" --exclude="node_modules" --exclude="deploy.tar.gz" --exclude=".vscode" .
        if (-not (Test-Path "deploy.tar.gz")) {
            throw "Failed to create deployment package"
        }
        Write-SubStep "Package created successfully" -Status "Success"
        
        # Transfer package
        Write-Step "Transferring Files"
        scp -i $SshKeyPath deploy.tar.gz "root@${VPS}:/tmp/"
        Write-SubStep "Files transferred successfully" -Status "Success"
    }
    finally {
        Pop-Location
    }
    
    # 5. Deploy
    Write-Step "Deploying Application"
    $deployScript = @'
#!/bin/bash
set -e

echo "Extracting files..."
cd /var/www/jouw-frontend-website
tar -xzf /tmp/deploy.tar.gz

echo "Setting up environment..."
cat > .env << EOL
NODE_ENV=production
NEXT_PUBLIC_API_URL=http://153.92.223.23:1337
NEXT_PUBLIC_BACKEND_URL=http://153.92.223.23:1337
NEXT_PUBLIC_SITE_URL=https://maasiso.nl
NEXT_PUBLIC_STRAPI_TOKEN=6615dd3e4c34a3dbee678b75077450028605e4110a2ac4414294618f91770cd2c1121f5539af11487a0cb4142a34f5d0db81b49c7aabd14481c5cf029aa4c257a89326bb00492f2130cdd07fae6141f1e266e9a7773e9f215ab4e133719bf7455b2d24ea16a2e3bbceb396e1b4c1fb95e1d4755f67666902fe3b1d734c236f86
EOL

chmod 600 .env
rm /tmp/deploy.tar.gz

echo "Installing dependencies..."
npm install --no-audit --no-fund --legacy-peer-deps --production

echo "Cleaning up and restarting application..."
# Stop all Node processes
pkill -f node || true
sleep 2

# Clear Node.js cache
rm -rf /tmp/node-*
rm -rf ~/.npm/_cacache

# Stop and remove PM2 process
pm2 stop frontend || true
pm2 delete frontend || true
pm2 flush

# Clear PM2 logs
pm2 flush

# Start application with PM2
NODE_ENV=production pm2 start ecosystem.config.js
pm2 save

# Give the application time to start
sleep 5

echo "Verifying deployment..."
for i in {1..30}; do
    if curl -s http://localhost:3000/api/health > /dev/null; then
        echo "Application is healthy"
        exit 0
    fi
    sleep 2
done

echo "Health check failed"
exit 1
'@
    
    # Save deploy script with Unix line endings and no BOM
    $deployScript = $deployScript.Replace("`r`n", "`n")
    $tempFile = [System.IO.Path]::GetTempFileName()
    $utf8NoBom = New-Object System.Text.UTF8Encoding $false
    [System.IO.File]::WriteAllText($tempFile, $deployScript, $utf8NoBom)
    
    # Transfer and execute deployment script
    scp -i $SshKeyPath $tempFile "root@${VPS}:/tmp/deploy.sh"
    ssh -i $SshKeyPath "root@$VPS" "chmod +x /tmp/deploy.sh && /tmp/deploy.sh"
    Write-SubStep "Deployment completed successfully" -Status "Success"
    
    # 6. Cleanup
    Write-Step "Cleaning Up"
    Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
    
    # Cleanup old backups
    $cleanupCommand = "cd $BackupDir && ls -t *.tar.gz | tail -n +6 | xargs rm -f 2>/dev/null || true"
    $cleanupCommand = $cleanupCommand -replace "`r`n", "`n"
    ssh -i $SshKeyPath "root@$VPS" $cleanupCommand
    
    $endTime = Get-Date
    $duration = $endTime - $startTime
    
    Write-Step "Deployment Completed Successfully!"
    Write-Host "Duration: $($duration.Minutes)m $($duration.Seconds)s"
    Write-Host "Frontend URL: https://maasiso.nl"
    Write-Host "Strapi URL: http://153.92.223.23:1337"
    Write-Host "`nMonitoring Commands:"
    Write-Host "1. View logs: ssh -i `"$SshKeyPath`" root@$VPS 'pm2 logs frontend'"
    Write-Host "2. Check status: ssh -i `"$SshKeyPath`" root@$VPS 'pm2 show frontend'"
    Write-Host "3. Monitor health: ./scripts/monitor-health.ps1"
    
} catch {
    Write-Step "Deployment Failed!"
    Write-Host "Error: $_" -ForegroundColor Red
    
    if (-not $backupName) {
        Write-SubStep "No backup was created - cannot perform rollback" -Status "Warning"
        exit 1
    }
    
    # Attempt rollback
    Write-Step "Rolling Back to Previous Version"
    try {
        $rollbackScript = @'
#!/bin/bash
cd /var/www/jouw-frontend-website
pm2 stop frontend || true
pm2 delete frontend || true
rm -rf .next node_modules package.json package-lock.json server.js ecosystem.config.js
tar -xzf /var/www/backups/BACKUP_NAME
npm install --no-audit --no-fund --legacy-peer-deps --production
pm2 start ecosystem.config.js
pm2 save
'@
        
        $rollbackScript = $rollbackScript.Replace("BACKUP_NAME", $backupName)
        $rollbackScript = $rollbackScript.Replace("`r`n", "`n")
        
        $tempRollbackFile = [System.IO.Path]::GetTempFileName()
        [System.IO.File]::WriteAllText($tempRollbackFile, $rollbackScript, $utf8NoBom)
        
        scp -i $SshKeyPath $tempRollbackFile "root@${VPS}:/tmp/rollback.sh"
        ssh -i $SshKeyPath "root@$VPS" "chmod +x /tmp/rollback.sh && /tmp/rollback.sh"
        
        Write-SubStep "Rollback completed successfully" -Status "Success"
        Remove-Item $tempRollbackFile -Force -ErrorAction SilentlyContinue
    } catch {
        Write-SubStep "Rollback failed: $_" -Status "Error"
        Write-SubStep "Manual intervention required!" -Status "Error"
    }
    
    # Final cleanup
    Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    exit 1
}