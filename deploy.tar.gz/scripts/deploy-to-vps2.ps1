# Build the frontend with production optimizations
Write-Host "Building frontend..."
npm run build:prod

# Create the production .env file
$envContent = @"
NEXT_PUBLIC_API_URL=/api/proxy
STRAPI_URL=http://153.92.223.23:1337
NEXT_PUBLIC_BACKEND_URL=http://153.92.223.23:1337
NEXT_PUBLIC_SITE_URL=https://maasiso.nl
NODE_ENV=production
"@

Set-Content -Path ".env.production" -Value $envContent

# Ensure correct directory structure on VPS2
Write-Host "Setting up remote directory structure..."
ssh root@147.93.62.188 "mkdir -p /var/www/frontend && rm -rf /var/www/frontend/*"

# Deploy to VPS2 using SFTP
Write-Host "Deploying to VPS2..."
Write-Host "Please use VS Code SFTP extension to upload the following:"
Write-Host "1. .next directory -> /var/www/frontend/.next"
Write-Host "2. public directory -> /var/www/frontend/public"
Write-Host "3. package.json -> /var/www/frontend/package.json"
Write-Host "4. package-lock.json -> /var/www/frontend/package-lock.json"
Write-Host "5. ecosystem.config.js -> /var/www/frontend/ecosystem.config.js"
Write-Host "6. .env.production -> /var/www/frontend/.env.production"

# Instructions for post-deployment steps
Write-Host "`nAfter SFTP upload, the following commands will be executed:"
Write-Host "1. Installing dependencies and setting up standalone"
ssh root@147.93.62.188 "cd /var/www/frontend && npm install --legacy-peer-deps && cp -r node_modules .next/standalone/"

Write-Host "2. Stopping existing PM2 process"
ssh root@147.93.62.188 "pm2 stop frontend || true && pm2 delete frontend || true"

Write-Host "3. Starting new PM2 process"
ssh root@147.93.62.188 "cd /var/www/frontend && pm2 start ecosystem.config.js --env production"

Write-Host "4. Saving PM2 process list"
ssh root@147.93.62.188 "pm2 save"

Write-Host "`nDeployment complete. To verify:"
Write-Host "1. Check PM2 status: ssh root@147.93.62.188 'pm2 status'"
Write-Host "2. Check logs: ssh root@147.93.62.188 'pm2 logs frontend'"
Write-Host "3. Access the website at https://maasiso.nl"