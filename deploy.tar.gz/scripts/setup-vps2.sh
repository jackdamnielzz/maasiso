#!/bin/bash

# Stop and remove existing PM2 process
pm2 stop frontend || true
pm2 delete frontend || true

# Clean up existing directories
rm -rf /var/www/frontend/*
rm -rf /var/www/jouw-frontend-website

# Create new directory structure
mkdir -p /var/www/frontend
chown -R www-data:www-data /var/www/frontend

# Update Nginx configuration
cat > /etc/nginx/sites-available/frontend << 'EOL'
server {
    listen 80;
    server_name maasiso.nl www.maasiso.nl;

    root /var/www/frontend;

    # Static files
    location /_next/static {
        alias /var/www/frontend/.next/static;
        expires 365d;
        access_log off;
        add_header Cache-Control "public, no-transform";
    }

    # Public static files
    location /public {
        alias /var/www/frontend/public;
        expires 365d;
        access_log off;
        add_header Cache-Control "public, no-transform";
    }

    # Other static assets
    location ~ ^/(images|styles|js)/ {
        root /var/www/frontend/public;
        expires 365d;
        access_log off;
        add_header Cache-Control "public, no-transform";
    }

    # Main application
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_read_timeout 60s;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;

        # Add error logging
        error_log /var/log/nginx/frontend_error.log debug;
        access_log /var/log/nginx/frontend_access.log;
    }

    # Strapi proxy
    location /api/proxy {
        rewrite ^/api/proxy/(.*) /$1 break;
        proxy_pass http://153.92.223.23:1337;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 60s;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
    }

    # Error pages
    error_page 404 /404.html;
    location = /404.html {
        root /var/www/frontend/public;
        internal;
    }

    error_page 500 502 503 504 /50x.html;
    location = /50x.html {
        root /var/www/frontend/public;
        internal;
    }

    # Additional security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
}
EOL

# Enable the site and restart nginx
ln -sf /etc/nginx/sites-available/frontend /etc/nginx/sites-enabled/frontend
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl restart nginx

# Create log directories with proper permissions
mkdir -p /var/log/nginx
touch /var/log/nginx/frontend_error.log /var/log/nginx/frontend_access.log
chown -R www-data:www-data /var/log/nginx

echo "VPS2 setup complete. You can now run deploy-to-vps2.ps1 to deploy the application."