'use client';

export function DeploymentTimestamp() {
  const buildTimestamp = process.env.NEXT_PUBLIC_BUILD_TIMESTAMP;

  return (
    <div className="text-center py-4 text-sm text-gray-500 border-t">
      Laatste update: {buildTimestamp}
    </div>
  );
}