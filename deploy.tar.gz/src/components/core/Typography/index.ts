import Typography from './Typography';

export { Typography };
export type { TypographyProps } from './Typography';

export default Typography;