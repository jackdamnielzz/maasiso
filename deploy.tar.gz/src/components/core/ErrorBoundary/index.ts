import { ErrorBoundary, DefaultErrorFallback } from './ErrorBoundary';

export { ErrorBoundary, DefaultErrorFallback };
export default ErrorBoundary;