import Button from './Button';

export { Button };
export type { ButtonProps } from './Button';

export default Button;