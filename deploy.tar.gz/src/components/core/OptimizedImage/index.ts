import OptimizedImage from './OptimizedImage';

export { OptimizedImage };
export type { OptimizedImageProps } from './OptimizedImage';

export default OptimizedImage;