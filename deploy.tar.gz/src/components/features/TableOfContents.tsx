"use client";

import React from 'react';

interface TableOfContentsProps {
  content: string;
}

interface TocItem {
  id: string;
  title: string;
}

const TableOfContents: React.FC<TableOfContentsProps> = ({ content }) => {
  const extractHeadings = (markdown: string): TocItem[] => {
    const headingRegex = /(?:\*\*(Artikel\s+\d+[:.][^*]+)\*\*|^##\s+(\d+\.\s+[^\n]+)|^##\s+([^\n]+))/gm;
    const headings: TocItem[] = [];
    let match;

    while ((match = headingRegex.exec(markdown)) !== null) {
      const title = (match[1] || match[2] || match[3]).trim();
      const id = title
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');

      if (title) {
        headings.push({ id, title });
      }
    }

    return headings;
  };

  const headings = extractHeadings(content);
  
  if (headings.length === 0) {
    return null;
  }

  return (
    <nav className="bg-white rounded-lg shadow-lg p-8 mb-8">
      <h2 className="text-2xl font-semibold text-[#172B4D] mb-6">Inhoudsopgave</h2>
      <ul className="space-y-4">
        {headings.map((heading) => (
          <li
            key={heading.id}
            className="text-[1.125rem]"
          >
            <a
              href={`#${heading.id}`}
              className="text-blue-600 hover:text-blue-800 hover:underline transition-colors duration-200"
            >
              {heading.title}
            </a>
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default TableOfContents;