'use client';

import { Suspense } from 'react';
import NewsPageClient from './NewsPageClient';
import LoadingSpinner from '@/components/common/LoadingSpinner';
import { NewsArticle, Page } from '@/lib/types';

interface NewsPageClientWrapperProps {
  page: Page;
  articles: NewsArticle[];
}

export default function NewsPageClientWrapper({
  page,
  articles
}: NewsPageClientWrapperProps) {
  return (
    <Suspense fallback={
      <div className="flex justify-center items-center min-h-[200px]">
        <LoadingSpinner />
      </div>
    }>
      <NewsPageClient
        page={page}
        articles={articles}
      />
    </Suspense>
  );
}