'use client';

import useSWR from 'swr';
import NewsPageContent from './NewsPageServer';
import { NewsArticle, Page } from '@/lib/types';
import LoadingSpinner from '@/components/common/LoadingSpinner';

interface NewsPageClientProps {
  page: Page;
  articles: NewsArticle[];
}

const fetcher = async (url: string) => {
  const res = await fetch(url);
  if (!res.ok) throw new Error('Failed to fetch news articles');
  const data = await res.json();
  return data;
};

export default function NewsPageClient({ page, articles: initialArticles }: NewsPageClientProps) {
  const { data, error } = useSWR('/api/proxy/news-articles?populate=*&sort=publishedAt:desc', fetcher, {
    fallbackData: { articles: initialArticles },
    refreshInterval: 5000, // Poll every 5 seconds
    revalidateOnFocus: true,
    revalidateOnReconnect: true
  });

  if (error) {
    return <div className="text-red-600">Error loading news articles</div>;
  }

  if (!data) {
    return (
      <div className="flex justify-center items-center min-h-[200px]">
        <LoadingSpinner />
      </div>
    );
  }

  const articles = data.articles || initialArticles;

  return <NewsPageContent page={page} articles={articles} />;
}
