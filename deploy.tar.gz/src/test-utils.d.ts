interface Window {
  triggerEvent(event: string, data: any): void;
}