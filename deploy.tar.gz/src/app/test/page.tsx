export default function TestPage() {
  console.log('Rendering TestPage');
  return (
    <div>
      <h1>Test Page</h1>
      <p>If you can see this, the page is rendering correctly.</p>
    </div>
  );
}
