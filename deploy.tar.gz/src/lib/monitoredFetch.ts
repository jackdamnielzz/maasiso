import { fetchWithRetry, RetryConfig } from './retry';
import { monitoringService } from './monitoring/service';
import { FetchOptions } from './api/cache';
import { clientEnv } from './config/client-env';
import logger from './logger';
import { MonitoringEventTypes } from './monitoring/types';

const DEBUG = process.env.DEBUG === 'true';

function getFullUrl(url: string): string {
  // If it's already a full URL, return it
  if (url.startsWith('http')) {
    return url;
  }

  // Route all API requests through proxy
  if (url.includes('/api/blog-posts')) {
    url = url.replace('/api/blog-posts', '/api/proxy/blog-posts');
  } else if (url.includes('/api/news-articles')) {
    url = url.replace('/api/news-articles', '/api/proxy/news-articles');
  } else if (url.includes('/api/pages')) {
    url = url.replace('/api/pages', '/api/proxy/pages');
  }

  // Use current origin on client side
  if (typeof window !== 'undefined') {
    return `${window.location.origin}${url.startsWith('/') ? '' : '/'}${url}`;
  }

  // Use configured URL on server side
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3002';
  return `${baseUrl}${url.startsWith('/') ? '' : '/'}${url}`;
}

/**
 * Wraps fetchWithRetry with performance monitoring
 */
export async function monitoredFetch(
  endpoint: string,
  url: string,
  options?: FetchOptions,
  retryConfig?: RetryConfig
): Promise<Response> {
  const startTime = Date.now();
  const fullUrl = getFullUrl(url);

  try {
    // Log request details in development
    if (process.env.NODE_ENV === 'development') {
      console.log('[API Request]', {
        endpoint,
        url: fullUrl,
        method: options?.method || 'GET',
        headers: {
          ...options?.headers,
          'Authorization': '[REDACTED]'
        }
      });
    }

    // Get the token and ensure it's properly formatted
    const token = clientEnv.strapiToken;
    const formattedToken = token.startsWith('Bearer ') ? token : `Bearer ${token}`;

    const response = await fetchWithRetry(fullUrl, {
      ...options,
      method: options?.method || 'GET',
      mode: 'cors',
      headers: {
        ...options?.headers,
        'Authorization': formattedToken,
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    }, retryConfig);

    if (response.status === 401) {
      console.error('[Auth Error] Token:', token ? '[REDACTED]' : 'MISSING');
      throw new Error('Authentication failed: Invalid or expired token');
    }

    if (!response.ok) {
      // Log response details for debugging
      // Get response body for error details if possible
      const errorBody = await response.text().catch(() => 'Could not read error body');
      
      console.error('[API Error]', {
        status: response.status,
        statusText: response.statusText,
        url: response.url,
        headers: Object.fromEntries(response.headers.entries()),
        body: errorBody
      });
      throw new Error(`API request failed: ${response.status} ${response.statusText}`);
    }

    monitoringService.trackEvent(MonitoringEventTypes.REQUEST, {
      method: options?.method || 'GET',
      url: fullUrl,
      duration: Date.now() - startTime,
      status: response.status
    });

    return response;
  } catch (error) {
    const status = error instanceof Error && 'status' in error
      ? (error as { status: number }).status
      : 500;

    const currentTime = Date.now();
    if (DEBUG) {
      logUniqueErrors(fullUrl, options?.method || 'GET', status, error);
    }

    monitoringService.trackEvent(MonitoringEventTypes.REQUEST, {
      method: options?.method || 'GET',
      url: fullUrl,
      duration: currentTime - startTime,
      status,
      error: error instanceof Error ? error : new Error(String(error))
    });

    throw error;
  }
}

function logUniqueErrors(url: string, method: string, status: number, error: unknown) {
  const errorKey = `${url}:${method}:${status}`;
  if (!loggedErrors.has(errorKey)) {
    loggedErrors.add(errorKey);
    logger.error('[API Error]', {
      url,
      method,
      status,
      message: error instanceof Error ? error.message : String(error)
    });
  }
}

const loggedErrors = new Set<string>();
