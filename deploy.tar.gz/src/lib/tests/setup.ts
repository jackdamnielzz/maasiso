// Import browser environment setup
import './setup/browser-env';

// Add any additional test setup here
