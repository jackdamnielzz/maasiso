import {
  BlogPost,
  NewsArticle,
  Page,
  SearchParams,
  StrapiCollectionResponse,
  StrapiData,
  StrapiSingleResponse,
  StrapiError,
  RawStrapiComponent,
  RawHeroComponent,
  RawFeatureGridComponent,
  RawFeature,
  RawTextBlockComponent,
  RawButtonComponent,
  RawGalleryComponent,
  Whitepaper,
  SEOMetadata,
  Image,
  PageComponent
} from './types';
import { extractFeatures } from './featureExtractor';
import { monitoredFetch } from './monitoredFetch';
import { validateSlug } from './utils/slugUtils';

class APIError extends Error {
  status: number;
  details?: any;

  constructor(message: string, status: number, details?: any) {
    super(message);
    this.name = 'APIError';
    this.status = status;
    this.details = details;
  }
}

// Always use the API URL for requests
const getBaseUrl = () => {
  return process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';
};

const API_TOKEN = process.env.NEXT_PUBLIC_STRAPI_TOKEN;

// Ensure proper Bearer token format and handle missing token
const getAuthHeaders = () => {
  if (!API_TOKEN) {
    throw new APIError('API token is missing', 401);
  }
  return {
    'Authorization': `Bearer ${API_TOKEN.replace(/^Bearer\s+/, '')}`,
    'Content-Type': 'application/json'
  };
};

async function fetchWithBaseUrl<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  try {
    const baseUrl = getBaseUrl();
    if (!baseUrl) {
      throw new APIError('API base URL is not configured', 500);
    }

    const url = `${baseUrl}${path.startsWith('/') ? '' : '/'}${path}`;
    const response = await monitoredFetch(
      path,
      url,
      {
        ...options,
        headers: {
          ...getAuthHeaders(),
          ...options.headers
        }
      }
    );

    const data = await response.json();
    return data;
  } catch (error) {
    if (error instanceof APIError) {
      throw error;
    }
    throw new APIError(
      error instanceof Error ? error.message : 'Unknown error occurred',
      500
    );
  }
}

function mapNewsArticle(data: any | null): NewsArticle | null {
  if (!data) {
    return null;
  }
  return {
    id: String(data.id),
    title: data.title || '',
    content: data.content || '',
    summary: data.summary || '',
    slug: data.slug || '',
    createdAt: data.createdAt || new Date().toISOString(),
    updatedAt: data.updatedAt || new Date().toISOString(),
    publishedAt: data.publishedAt,
    author: data.author || '',
    tags: data.tags?.map((tag: any) => ({
      id: String(tag.id),
      name: tag.name
    })) || [],
    categories: data.categories?.map((category: any) => ({
      id: String(category.id),
      name: category.name,
      slug: category.slug || '',
      description: category.description || '',
      createdAt: category.createdAt || new Date().toISOString(),
      updatedAt: category.updatedAt || new Date().toISOString()
    })) || [],
    featuredImage: data.featuredImage ? mapImage(data.featuredImage) : undefined,
    seoTitle: data.seoTitle || '',
    seoDescription: data.seoDescription || '',
    seoKeywords: data.seoKeywords || ''
  };
}

function mapBlogPost(data: any | null): BlogPost | null {
  if (!data) {
    console.log('Invalid blog post data:', data);
    return null;
  }

  if (!data.Content || !data.title) {
    console.warn('Missing required fields:', { content: !!data.Content, title: !!data.title });
    return null;
  }

  return {
    id: String(data.id),
    title: data.title,
    content: data.Content,
    summary: data.summary || '',
    slug: data.slug || '',
    createdAt: data.createdAt || new Date().toISOString(),
    updatedAt: data.updatedAt || new Date().toISOString(),
    publishedAt: data.publishedAt,
    seoTitle: data.seoTitle || data.title,
    seoDescription: data.seoDescription || '',
    seoKeywords: data.seoKeywords || '',
    author: data.Author || '',
    tags: Array.isArray(data.tags) ? data.tags.map((tag: any) => ({
      id: String(tag.id),
      name: tag.name || ''
    })) : [],
    featuredImage: data.featuredImage ? mapImage(data.featuredImage) : undefined
  };
}

function mapWhitepaper(data: any | null): Whitepaper | null {
  if (!data) {
    console.log('mapWhitepaper received null data');
    return null;
  }
  
  return {
    id: String(data.id),
    title: data.title || '',
    slug: data.slug || '',
    description: data.description || '',
    version: data.version || '1.0',
    author: data.author || '',
    downloadLink: data.file?.data?.attributes?.url || '',
    createdAt: data.createdAt || new Date().toISOString(),
    updatedAt: data.updatedAt || new Date().toISOString(),
    publishedAt: data.publishedAt
  };
}

function mapImage(data: any): Image | undefined {
  if (!data) {
    return undefined;
  }
  // Handle flat image structure
  return {
    id: String(data.id),
    name: data.name || '',
    alternativeText: data.alternativeText || '',
    caption: data.caption || '',
    width: data.width || 0,
    height: data.height || 0,
    formats: data.formats || {},
    hash: data.hash || '',
    ext: data.ext || '',
    mime: data.mime || '',
    size: data.size || 0,
    url: data.url ? `${getBaseUrl()}${data.url}` : '',
    previewUrl: data.previewUrl,
    provider: data.provider || '',
    provider_metadata: data.provider_metadata,
    createdAt: data.createdAt || new Date().toISOString(),
    updatedAt: data.updatedAt || new Date().toISOString(),
    publishedAt: data.publishedAt || new Date().toISOString()
  };
}

function validatePageComponent(component: RawStrapiComponent, index: number): boolean {
  if (!component || !component.__component) {
    console.warn(`[API Validation] Invalid component at index ${index}: Missing __component property`);
    return false;
  }

  let isValid = true;
  const componentType = component.__component.split('.')[1];
  
  switch (componentType) {
    case 'hero':
      const heroComponent = component as RawHeroComponent;
      if (!heroComponent.title) {
        console.warn(`[API Validation] Hero component missing title at index ${index}`);
        isValid = false;
      }
      if (heroComponent.ctaButton && (!heroComponent.ctaButton.text || !heroComponent.ctaButton.link)) {
        console.warn(`[API Validation] Hero component has incomplete ctaButton at index ${index}`);
        isValid = false;
      }
      break;
      
    case 'feature-grid':
      console.log('[API Validation] Feature grid component found, considering valid for frontend fallback rendering');
      return true;
      
    case 'text-block':
      const textBlockComponent = component as RawTextBlockComponent;
      if (!textBlockComponent.content) {
        console.warn(`[API Validation] Text block missing content at index ${index}`);
        isValid = false;
      }
      break;
      
    case 'button':
      const buttonComponent = component as RawButtonComponent;
      if (!buttonComponent.text || !buttonComponent.link) {
        console.warn(`[API Validation] Button component missing text or link at index ${index}`);
        isValid = false;
      }
      break;
      
    case 'gallery':
      const galleryComponent = component as RawGalleryComponent;
      if (!galleryComponent.images?.data || galleryComponent.images.data.length === 0) {
        console.warn(`[API Validation] Gallery component missing images at index ${index}`);
        isValid = false;
      }
      break;
  }
  
  return isValid;
}

function mapPage(data: any | null): Page | null {
  if (!data) {
    console.log('mapPage received null data');
    return null;
  }
  
  console.log('Page data structure:', {
    id: data.id,
    availableFields: Object.keys(data),
    hasLayout: Array.isArray(data.layout),
    layoutLength: Array.isArray(data.layout) ? data.layout.length : 0
  });
  
  const seoMetadata: SEOMetadata = {
    metaTitle: data.seoTitle || '',
    metaDescription: data.seoDescription || '',
    keywords: data.seoKeywords || ''
  };
  
  if (Array.isArray(data.layout)) {
    let validationIssues = false;
    data.layout.forEach((component: RawStrapiComponent, index: number) => {
      if (!validatePageComponent(component, index)) {
        validationIssues = true;
      }
    });
    
    if (validationIssues) {
      console.warn('[API Validation] Some components have validation issues. Check logs above for details.');
    }
  }
  
  return {
    id: String(data.id),
    title: data.title || '',
    slug: data.slug || '',
    seoMetadata,
    layout: data.layout?.map((component: any) => {
      const baseComponent = {
        id: component.id,
        __component: component.__component
      };

      switch (component.__component) {
        case 'page-blocks.hero':
          return {
            ...baseComponent,
            title: component.title || '',
            subtitle: component.subtitle || '',
            backgroundImage: component.backgroundImage ? mapImage(component.backgroundImage) : undefined,
            ctaButton: component.ctaButton
          };
        case 'page-blocks.text-block':
          return {
            ...baseComponent,
            content: component.content || '',
            alignment: component.alignment || 'left'
          };
        case 'page-blocks.gallery':
          return {
            ...baseComponent,
            images: component.images?.map((img: any) => mapImage(img)).filter(Boolean) || [],
            layout: component.layout || 'grid'
          };
        case 'page-blocks.feature-grid':
          console.log('Feature grid component found:', {
            id: component.id || 'unknown',
            hasFeatures: 'features' in component,
            componentKeys: Object.keys(component)
          });
          
          return {
            ...baseComponent,
            features: extractFeatures(component)
          };
        case 'page-blocks.button':
          return {
            ...baseComponent,
            text: component.text || '',
            link: component.link || '',
            style: component.style || 'primary'
          };
        default:
          return baseComponent;
      }
    }) || [],
    publishedAt: data.publishedAt,
    createdAt: data.createdAt || new Date().toISOString(),
    updatedAt: data.updatedAt || new Date().toISOString()
  };
}

export async function getPage(slug: string): Promise<Page | null> {
  try {
    // Validate and sanitize the slug
    const validatedSlug = validateSlug(slug);
    console.log(`[getPage] Starting getPage for slug: ${validatedSlug} at ${new Date().toISOString()}`);

    // Use indexed populate parameters to avoid deep nesting issues
    const indexedPopulate = [
      'populate[0]=layout',
      'populate[1]=layout.features',
      'populate[2]=layout.features.icon',
      'populate[3]=layout.backgroundImage',
      'populate[4]=layout.ctaButton'
    ].join('&');

    const data = await fetchWithBaseUrl<StrapiCollectionResponse<any>>(
      `/api/pages?filters[slug][$eq]=${validatedSlug}&${indexedPopulate}`,
      { next: { revalidate: 60 } }
    );

    return data.data && data.data.length > 0 ? mapPage(data.data[0]) : null;
  } catch (error) {
    console.error('[getPage] Error:', error);
    return null;
  }
}

export async function getNewsArticles(page = 1, pageSize = 10): Promise<{ articles: NewsArticle[]; total: number }> {
  try {
    const data = await fetchWithBaseUrl<StrapiCollectionResponse<NewsArticle>>(
      `/api/news-articles?pagination[page]=${page}&pagination[pageSize]=${pageSize}&populate=*&sort=publishedAt:desc`,
      { next: { revalidate: 60 } }
    );

    console.log('Raw News Articles Response:', JSON.stringify(data, null, 2));

    const articles = data.data
      .map(article => mapNewsArticle(article))
      .filter((article): article is NewsArticle => article !== null);

    return {
      articles,
      total: data.meta.pagination?.total || 0
    };
  } catch (error) {
    console.error('Error fetching news articles:', error);
    return { articles: [], total: 0 };
  }
}

export async function getNewsArticleBySlug(slug: string): Promise<NewsArticle | null> {
  try {
    // Validate and sanitize the slug
    const validatedSlug = validateSlug(slug);

    const data = await fetchWithBaseUrl<StrapiCollectionResponse<NewsArticle>>(
      `/api/news-articles?filters[slug][$eq]=${validatedSlug}&populate=*`,
      { next: { revalidate: 60 } }
    );
    
    if (!data.data || data.data.length === 0) {
      return null;
    }

    return mapNewsArticle(data.data[0]);
  } catch (error) {
    console.error('Error fetching news article:', error);
    return null;
  }
}

export async function getRelatedNewsArticles(currentSlug: string): Promise<NewsArticle[]> {
  try {
    const filters = [];
    // Validate and sanitize the slug
    const validatedSlug = validateSlug(currentSlug);

    filters.push(`filters[slug][$ne]=${currentSlug}`);

    const data = await fetchWithBaseUrl<StrapiCollectionResponse<NewsArticle>>(
      `/api/proxy/news-articles?${filters.join('&')}&populate=*&pagination[limit]=3`,
      { next: { revalidate: 60 } }
    );

    return data.data
      .map(article => mapNewsArticle(article))
      .filter((article): article is NewsArticle => article !== null);
  } catch (error) {
    console.error('Error fetching related news articles:', error);
    return [];
  }
}

export async function getBlogPostBySlug(slug: string): Promise<{ blogPost: BlogPost | null }> {
  try {
    // Validate and sanitize the slug
    const validatedSlug = validateSlug(slug);

    const data = await fetchWithBaseUrl<StrapiCollectionResponse<BlogPost>>(
      `/api/blog-posts?filters[slug][$eq]=${validatedSlug}&populate=*`,
      {
        next: { revalidate: 60 },
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        }
      }
    );

    console.log('Blog by slug response:', JSON.stringify(data, null, 2));
    
    if (!data.data || data.data.length === 0) {
      return { blogPost: null };
    }

    return { blogPost: mapBlogPost(data.data[0]) };
  } catch (error) {
    console.error('Error fetching blog post:', error);
    return { blogPost: null };
  }
}

export async function search(params: SearchParams): Promise<{
  blogPosts: { data: BlogPost[]; meta: { pagination: { total: number } } };
  newsArticles: { data: NewsArticle[]; meta: { pagination: { total: number } } };
}> {
  try {
    const filters = [];
    if (params.filters?.contentType?.length) {
      filters.push(`filters[type][$in]=${params.filters.contentType.join(',')}`);
    }
    if (params.filters?.dateFrom) {
      filters.push(`filters[publishedAt][$gte]=${params.filters.dateFrom}`);
    }
    if (params.filters?.dateTo) {
      filters.push(`filters[publishedAt][$lte]=${params.filters.dateTo}`);
    }
    
    filters.push(`filters[$or][0][title][$containsi]=${params.query}`);
    filters.push(`filters[$or][1][content][$containsi]=${params.query}`);

    const sort = params.sort ? `sort=${params.sort.field}:${params.sort.direction}` : 'sort=publishedAt:desc';

    const blogData = await fetchWithBaseUrl<StrapiCollectionResponse<BlogPost>>(
      `/api/proxy/blog-posts?${filters.join('&')}&${sort}&pagination[page]=${params.page}&pagination[pageSize]=${params.pageSize}&populate=*`,
      { next: { revalidate: 60 } }
    );

    const newsData = await fetchWithBaseUrl<StrapiCollectionResponse<NewsArticle>>(
      `/api/news-articles?${filters.join('&')}&${sort}&pagination[page]=${params.page}&pagination[pageSize]=${params.pageSize}&populate=*`,
      { next: { revalidate: 60 } }
    );

    return {
      blogPosts: {
        data: blogData.data.map(post => mapBlogPost(post)).filter((post): post is BlogPost => post !== null),
        meta: {
          pagination: {
            total: blogData.meta.pagination?.total || 0
          }
        }
      },
      newsArticles: {
        data: newsData.data.map(article => mapNewsArticle(article)).filter((article): article is NewsArticle => article !== null),
        meta: {
          pagination: {
            total: newsData.meta.pagination?.total || 0
          }
        }
      }
    };
  } catch (error) {
    console.error('Search error:', error);
    return {
      blogPosts: { data: [], meta: { pagination: { total: 0 } } },
      newsArticles: { data: [], meta: { pagination: { total: 0 } } }
    };
  }
}

export async function getBlogPosts(page = 1, pageSize = 10): Promise<{ posts: BlogPost[]; total: number }> {
  try {
    console.log('Fetching blog posts with params:', { page, pageSize });
    
    const data = await fetchWithBaseUrl<StrapiCollectionResponse<BlogPost>>(
      `/api/blog-posts?pagination[page]=${page}&pagination[pageSize]=${pageSize}&populate=*`,
      {
        next: { revalidate: 60 },
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        }
      }
    );

    console.log('Raw Strapi response:', {
      dataExists: !!data,
      hasData: !!data?.data,
      dataLength: data?.data?.length,
      meta: data?.meta,
      firstPost: data?.data?.[0],
    });

    const posts = data.data
      .map(post => {
        const mappedPost = mapBlogPost(post);
        console.log('Mapped post:', mappedPost);
        return mappedPost;
      })
      .filter((post): post is BlogPost => post !== null);

    const result = {
      posts,
      total: data.meta.pagination?.total || 0
    };
    
    console.log('Final posts result:', result);
    return result;
  } catch (error) {
    console.error('Error fetching blog posts:', error);
    return { posts: [], total: 0 };
  }
}

export async function getWhitepapers(page = 1, pageSize = 10): Promise<{ whitepapers: StrapiCollectionResponse<Whitepaper>; total: number }> {
  try {
    console.log('Fetching whitepapers with params:', { page, pageSize });
    
    const data = await fetchWithBaseUrl<StrapiCollectionResponse<any>>(
      `/api/whitepapers?pagination[page]=${page}&pagination[pageSize]=${pageSize}&populate=*`,
      {
        next: { revalidate: 60 },
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        }
      }
    );

    console.log('Raw Strapi whitepaper response:', {
      dataExists: !!data,
      hasData: !!data?.data,
      dataLength: data?.data?.length,
      meta: data?.meta
    });

    const whitepapers = {
      data: data.data.map(item => {
        const mappedWhitepaper = mapWhitepaper(item.attributes);
        return mappedWhitepaper ? { id: item.id, attributes: mappedWhitepaper } : null;
      }).filter((item): item is StrapiData<Whitepaper> => item !== null),
      meta: data.meta
    };

    return {
      whitepapers,
      total: data.meta.pagination?.total || 0
    };
  } catch (error) {
    console.error('Error fetching whitepapers:', error);
    return { whitepapers: { data: [], meta: { pagination: { page: 1, pageSize: 10, pageCount: 0, total: 0 } } }, total: 0 };
  }
}
